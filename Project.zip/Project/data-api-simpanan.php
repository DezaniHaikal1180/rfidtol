<?php
//error_reporting(0);
require "koneksi.php";

$ambilrfid	 = $_GET["rfid"];
$ambiltol	 = $_GET["nama_tol"];

date_default_timezone_set('Asia/Jakarta');
$tgl = date("Y-m-d G:i:s");

//AMBIL NAMA TOL RUBAH KE BAYAR
$gettol = query("SELECT * FROM tb_tol WHERE nama_tol='$ambiltol'")[0];
$ambilharga = $gettol['harga'];
$cektol     = $gettol['id_tol'];
$namatol     = $gettol['nama_tol'];
//echo $ambilbayar;

//AMBIL DATA SALDO DAN RFID DARI DATA YANG SUDAH ADA
$getsaldo = query("SELECT * FROM tb_user WHERE rfid='$ambilrfid'")[0];
$saldoawal = $getsaldo['saldo'];
$cekrfid   = $getsaldo['rfid'];
$nama   = $getsaldo['nama'];

if ($saldoawal < $ambilharga and $cektol != null) {
	$ceksaldo   = "kurang";
	$saldoawal  = $saldoawal;
	$keterangan = "Saldo Tidak Mencukupi";
}else if ($saldoawal > $ambilharga and $cektol != null){
	$ceksaldo = "cukup";
	$keterangan = "Transaksi Berhasil";

} else {

	$ceksaldo   = "Tidak Terdaftar";
	$saldoawal  = "Tidak Terdaftar";
	$keterangan = "Tidak Terdaftar";
}

//UPDATE DATA REALTIME PADA TABEL tb_monitoring
$sql      = "UPDATE tb_monitoring SET rfid='$ambilrfid', nama_tol='$ambiltol', saldo='$saldoawal', keterangan= '$keterangan'";
$koneksi->query($sql);

//KIRIM DATA PALSU KE ARDUINO JIKA REQUEST RFID TIDAK TERDAFTAR
//=================================================================//
if ($cekrfid == null or $cektol == null) {
	//MEMBUAT DATA UNTUK DIJADIKAN JSON DAN DIKIRIM KE ARDUIO
	$datadumy = array('id' => '0', 'rfid' => $ambilrfid, 'nama' => 'Tidak Terdaftar', 'alamat' => 'Tidak Terdaftar', 'telepon' => 'Tidak Terdaftar', 'saldo' => 'Tidak Terdaftar', 'tanggal' => $tgl, 'nama_tol' => $ambiltol, 'keterangan' => $keterangan);
	$result = json_encode($datadumy); //MENJADIKAN JSON DATA
	echo $result;
}

//KIRIM DATA KE ARDUINO JIKA REQUEST RFID TERDAFTAR DAN SALDO CUKUP
//=================================================================//
if ($ceksaldo == "cukup" and $cekrfid != null and $cektol != null){
	//PERINTAH PENGURANGAN SALDO
	$updatesaldo = $saldoawal - $ambilharga;

	//UPDATE DATA REALTIME PADA TABEL tb_daftarrfid  
	$sqlupdate = "UPDATE tb_user SET saldo ='$updatesaldo' WHERE rfid='$ambilrfid'";
	$koneksi->query($sqlupdate);

	//UPDATE DATA REALTIME PADA TABEL tb_monitoring
	$sql      = "UPDATE tb_monitoring SET tanggal	= '$tgl', rfid	= '$ambilrfid', nama	= '$nama', nama_tol	= '$ambiltol', saldo	= '$updatesaldo', ";
	$koneksi->query($sql);

	//INSERT DATA REALTIME PADA TABEL tb_save  	
	$sqlsave = "INSERT INTO tb_logdata (rfid , nama, saldo_awal, harga, saldo_akhir, nama_tol, tanggal, keterangan) VALUES ( '$ambilrfid', ' $nama ','$saldoawal', '$ambilharga ', '$updatesaldo', ' $ambiltol', '$tgl',  '$keterangan')";
	$koneksi->query($sqlsave);


	//MENGABIL DATA UNTUK DIJADIKAN JSON DAN DIKIRIM KE ARDUIO
	$response = query("SELECT rfid,nama,saldo,nama_tol,tanggal,keterangan FROM tb_user JOIN tb_monitoring USING (RFID )WHERE rfid='$ambilrfid'")[0];
	$result = json_encode($response); //MENJADIKAN JSON DATA
	echo $result;
}

//KIRIM DATA KE ARDUINO JIKA REQUEST RFID TERDAFTAR DAN SALDO TIDAK CUKUP
//=================================================================//
else if ($ceksaldo == "kurang" and $cekrfid != null) {
	//MENGABIL DATA UNTUK DIJADIKAN JSON DAN DIKIRIM KE ARDUIO
	$response = query("SELECT rfid,nama,saldo,nama_tol,tanggal,keterangan FROM tb_user JOIN tb_monitoring USING (RFID )WHERE rfid='$ambilrfid'")[0];
	$result = json_encode($response); //MENJADIKAN JSON DATA
	echo $result;
	//echo $ceksaldo;
	//echo $cekrfid;
}
