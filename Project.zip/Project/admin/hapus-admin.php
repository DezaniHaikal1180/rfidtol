<?php
include("koneksi.php");

$id_admin = $_GET['id_admin'];

$sql = "DELETE tb_login,tb_admin FROM tb_login JOIN tb_admin ON tb_admin.id_login = tb_login.id_login WHERE tb_admin.id_admin='$id_admin'";
$query = mysqli_query($koneksi, $sql);

if ($query) {
    // kalau berhasil alihkan ke halaman index.php dengan status=sukses
    header('Location: admin.php?status=sukses');
} else {
    // kalau gagal alihkan ke halaman indek.php dengan status=gagal
    header('Location: admin.php?status=gagal');
}
