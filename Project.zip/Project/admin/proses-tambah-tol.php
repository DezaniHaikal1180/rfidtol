<?php

include("koneksi.php");

// cek apakah tombol daftar sudah diklik atau blum?
if (isset($_POST['daftar'])) {

	// ambil data dari formulir
	$nama_tol = $_POST['nama_tol'];
	$harga = $_POST['harga'];

	// buat query
	$cektol = mysqli_num_rows(mysqli_query($koneksi, "SELECT * FROM tb_tol WHERE nama_tol='$_POST[nama_tol]'"));


	// apakah query simpan berhasil?
	if ($cektol > 0) {
		// kalau berhasil alihkan ke halaman index.php dengan status=sukses
		echo '<script language="javascript">
              alert ("Nama Tol Sudah Ada");
              window.location="tambah-tol.php";
              </script>';
		exit();
	} else {
		// kalau gagal alihkan ke halaman indek.php dengan status=gagal
		$sql = "INSERT INTO tb_tol (nama_tol, harga) VALUE ('$nama_tol', '$harga')";
		$query = mysqli_query($koneksi, $sql);
		header('Location: tol.php?status=sukses');
	}
} else {
	die("Akses dilarang...");
}
