<?php

include("koneksi.php");

// cek apakah tombol daftar sudah diklik atau blum?
if (isset($_POST['daftar'])) {

    // ambil data dari formulir
    $tgl = date("Y-m-d h:i:s");
    $topup      = $_POST['topup'];
    $id_user    = $_POST['id_user'];
    // buat query

    $akun   = query("SELECT * FROM tb_user WHERE id_user = '$id_user'")[0];
    $ambilrfid   = $akun['rfid'];
    $ambilnama   = $akun['nama'];
    $ambilsaldo  = $akun['saldo'];
    $saldoakhir  = $ambilsaldo + $topup;

    $sql   = "UPDATE tb_user  SET saldo = saldo + '$topup' WHERE id_user='$id_user'";
    $query = mysqli_query($koneksi, $sql);



    // apakah query simpan berhasil?
    if ($query) {
        // kalau berhasil alihkan ke halaman index.php dengan status=sukses
        $sqllog = "INSERT INTO tb_topup (tanggal, rfid, nama, saldo_awal, topup, saldo_akhir) VALUES ('" . $tgl . "', '" . $ambilrfid . "', '" . $ambilnama . "', '" . $ambilsaldo . "', '" . $topup . "' , '" . $saldoakhir . "')";
        $koneksi->query($sqllog);
        header('Location: log-topup.php?status=sukses');
    } else {
        // kalau gagal alihkan ke halaman indek.php dengan status=gagal
        header('Location: log-topup.php?status=gagal');
    }
} else {
    die("Akses dilarang...");
}
