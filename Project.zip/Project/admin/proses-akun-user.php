<?php
include("koneksi.php");
$username = $_POST['username'];
$password = sha1($_POST['password']);
$level = $_POST['level'];
$cekusername = mysqli_num_rows(mysqli_query($koneksi, "SELECT * FROM tb_login WHERE username='$_POST[username]'"));


//PERINTAH MENGECEK AGAR TIDAK TERDAPAT USER YANG SAMA


// cek apakah tombol daftar sudah diklik atau blum?
if ($cekusername > 0) {
	echo '<script language="javascript">
              alert ("User Sudah Ada Yang Menggunakan");
              window.location="daftar-akun-user.php";
              </script>';
	exit();

	// ambil data dari formulir
}
// buat query

// apakah query simpan berhasil?
// kalau berhasil alihkan ke halaman index.php dengan status=sukses

else {
	// kalau gagal alihkan ke halaman indek.php dengan status=gagal
	$sql = "INSERT INTO tb_login (username, password, level) VALUE ('$username', '$password', '$level')";
	$koneksi->query($sql);

	header('Location: daftar-user.php?status=sukses&username=' . $username . '');
}
