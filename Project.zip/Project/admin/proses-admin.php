<?php

include("koneksi.php");

// cek apakah tombol daftar sudah diklik atau blum?
if (isset($_POST['daftar'])) {

	// ambil data dari formulir
	$nama    = $_POST['nama'];
	$telepon = $_POST['telepon'];
    $alamat  = $_POST['alamat'];
    $id_login = $_POST['id_login'];
    
	// buat query
	$sql = "INSERT INTO tb_admin (nama, telepon, alamat, id_login) VALUE ('$nama', '$telepon', '$alamat', '$id_login')";
	$query = mysqli_query($koneksi, $sql);

	// apakah query simpan berhasil?
	if ($query) {
		// kalau berhasil alihkan ke halaman index.php dengan status=sukses
		header('Location: admin.php?status=sukses');
	} else {
		// kalau gagal alihkan ke halaman indek.php dengan status=gagal
		header('Location: admin.php?status=gagal');
	}
} else {
	die("Akses dilarang...");
}
