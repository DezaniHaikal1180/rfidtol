<?php
include("koneksi.php");

$id_user = $_GET['id_user'];

$sql = "DELETE tb_login,tb_user FROM tb_login JOIN tb_user ON tb_user.id_login = tb_login.id_login WHERE tb_user.id_user='$id_user'";
$query = mysqli_query($koneksi, $sql);

if ($query) {
    // kalau berhasil alihkan ke halaman index.php dengan status=sukses
    header('Location: data-user.php?status=sukses');
} else {
    // kalau gagal alihkan ke halaman indek.php dengan status=gagal
    header('Location: data-user.php?status=gagal');
}
