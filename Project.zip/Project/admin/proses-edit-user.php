<?php

include("koneksi.php");

// cek apakah tombol daftar sudah diklik atau blum?
if (isset($_POST['daftar'])) {

	// ambil data dari formulir
    $nama    = $_POST['rfid'];
	$nama    = $_POST['nama'];
	$telepon = $_POST['telepon'];
    $alamat  = $_POST['alamat'];
    $saldo  = $_POST['saldo'];
	// buat query
	$sql = "UPDATE tb_user  SET nama = '$nama' , telepon, alamat, saldo, rfid) VALUE ('', '$telepon', '$alamat', '$saldo', '$rfid')";
	$query = mysqli_query($koneksi, $sql);

	// apakah query simpan berhasil?
	if ($query) {
		// kalau berhasil alihkan ke halaman index.php dengan status=sukses
		header('Location: admin.php?status=sukses');
	} else {
		// kalau gagal alihkan ke halaman indek.php dengan status=gagal
		header('Location: admin.php?status=gagal');
	}
} else {
	die("Akses dilarang...");
}
