<?php

include("koneksi.php");




// cek apakah tombol daftar sudah diklik atau blum?
if (isset($_POST['daftar'])) {
	// ambil data dari formulir
	$rfid    = $_POST['rfid'];
	$nama    = $_POST['nama'];
	$telepon = $_POST['telepon'];
	$alamat  = $_POST['alamat'];
	$saldo  = $_POST['saldo'];
	$id_login = $_POST['id_login'];

	// buat query
	$cekrfid = mysqli_num_rows(mysqli_query($koneksi, "SELECT * FROM tb_user WHERE rfid='$_POST[rfid]'"));

	// apakah query simpan berhasil?
	if ($cekrfid > 0) {
		// kalau berhasil alihkan ke halaman index.php dengan status=sukses
		echo '<script language="javascript">
              alert ("RFID Sudah Ada Yang Menggunakan"); history.go(-1);
              </script>';
		exit();
	} else {
		// kalau gagal alihkan ke halaman indek.php dengan status=gagal
		$sql = "INSERT INTO tb_user (nama, telepon, alamat, saldo, rfid, id_login) VALUE ('$nama', '$telepon', '$alamat', '$saldo', '$rfid', '$id_login')";
		$koneksi->query($sql);
		header('Location: data-user.php?status=sukses');
	}
} else {
	die("Akses dilarang...");
}
